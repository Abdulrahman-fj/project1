
  # QR Smart Attendance App

  This is a code bundle for QR Smart Attendance App. The original project is available at https://www.figma.com/design/v97yo5phkqes6P1k1g0XXN/QR-Smart-Attendance-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  