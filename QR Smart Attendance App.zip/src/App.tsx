import { useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import Login from "./components/Login";
import AdminDashboard from "./components/admin/AdminDashboard";
import AdminNotifications from "./components/admin/AdminNotifications";
import AdminUsers from "./components/admin/AdminUsers";
import AdminAnalytics from "./components/admin/AdminAnalytics";
import AdminProfile from "./components/admin/AdminProfile";
import AdminSettings from "./components/admin/AdminSettings";
import ProfessorDashboard from "./components/professor/ProfessorDashboard";
import ProfessorAttendance from "./components/professor/ProfessorAttendance";
import ProfessorQR from "./components/professor/ProfessorQR";
import ProfessorReports from "./components/professor/ProfessorReports";
import ProfessorNotifications from "./components/professor/ProfessorNotifications";
import ProfessorProfile from "./components/professor/ProfessorProfile";
import ProfessorSettings from "./components/professor/ProfessorSettings";
import StudentDashboard from "./components/student/StudentDashboard";
import StudentAttendance from "./components/student/StudentAttendance";
import StudentReports from "./components/student/StudentReports";
import StudentScan from "./components/student/StudentScan";
import StudentProfile from "./components/student/StudentProfile";
import StudentNotifications from "./components/student/StudentNotifications";
import StudentSettings from "./components/student/StudentSettings";

function App() {
  const [userRole, setUserRole] = useState<string | null>(null);

  const handleLogin = (role: string) => {
    setUserRole(role);
  };

  const handleLogout = () => {
    setUserRole(null);
  };

  return (
    <Router>
      <Routes>
        <Route
          path="/login"
          element={<Login onLogin={handleLogin} />}
        />

        {/* Admin Routes */}
        <Route
          path="/admin/dashboard"
          element={
            userRole === "admin" ? (
              <AdminDashboard onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/admin/notifications"
          element={
            userRole === "admin" ? (
              <AdminNotifications onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/admin/users"
          element={
            userRole === "admin" ? (
              <AdminUsers onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/admin/analytics"
          element={
            userRole === "admin" ? (
              <AdminAnalytics onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/admin/profile"
          element={
            userRole === "admin" ? (
              <AdminProfile onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/admin/settings"
          element={
            userRole === "admin" ? (
              <AdminSettings onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />

        {/* Professor Routes */}
        <Route
          path="/professor/dashboard"
          element={
            userRole === "professor" ? (
              <ProfessorDashboard onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/professor/attendance"
          element={
            userRole === "professor" ? (
              <ProfessorAttendance onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/professor/qr"
          element={
            userRole === "professor" ? (
              <ProfessorQR onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/professor/reports"
          element={
            userRole === "professor" ? (
              <ProfessorReports onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/professor/notifications"
          element={
            userRole === "professor" ? (
              <ProfessorNotifications onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/professor/profile"
          element={
            userRole === "professor" ? (
              <ProfessorProfile onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/professor/settings"
          element={
            userRole === "professor" ? (
              <ProfessorSettings onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />

        {/* Student Routes */}
        <Route
          path="/student/dashboard"
          element={
            userRole === "student" ? (
              <StudentDashboard onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/student/attendance"
          element={
            userRole === "student" ? (
              <StudentAttendance onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/student/reports"
          element={
            userRole === "student" ? (
              <StudentReports onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/student/scan"
          element={
            userRole === "student" ? (
              <StudentScan onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/student/profile"
          element={
            userRole === "student" ? (
              <StudentProfile onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/student/notifications"
          element={
            userRole === "student" ? (
              <StudentNotifications onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/student/settings"
          element={
            userRole === "student" ? (
              <StudentSettings onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />

        {/* Default Route */}
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    </Router>
  );
}

export default App;