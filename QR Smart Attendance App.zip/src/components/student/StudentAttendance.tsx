import Sidebar from '../Sidebar';
import TopBar from '../TopBar';
import Badge from '../Badge';
import { Filter, Download } from 'lucide-react';

interface StudentAttendanceProps {
  onLogout: () => void;
}

const StudentAttendance = ({ onLogout }: StudentAttendanceProps) => {
  const courses = [
    { name: 'Computer Science 101', attendance: 98, present: 49, absent: 1, total: 50 },
    { name: 'Advanced Algorithms', attendance: 95, present: 19, absent: 1, total: 20 },
    { name: 'Data Structures', attendance: 92, present: 46, absent: 4, total: 50 },
    { name: 'Database Systems', attendance: 88, present: 44, absent: 6, total: 50 },
    { name: 'Software Engineering', attendance: 85, present: 17, absent: 3, total: 20 },
  ];

  const recentActivity = [
    { date: '2024-11-28', course: 'Computer Science 101', status: 'Present' },
    { date: '2024-11-28', course: 'Data Structures', status: 'Present' },
    { date: '2024-11-27', course: 'Advanced Algorithms', status: 'Present' },
    { date: '2024-11-27', course: 'Software Engineering', status: 'Absent' },
    { date: '2024-11-26', course: 'Database Systems', status: 'Present' },
    { date: '2024-11-26', course: 'Computer Science 101', status: 'Tardy' },
  ];

  const overallAttendance = 92;
  const totalPresent = courses.reduce((sum, c) => sum + c.present, 0);
  const totalAbsent = courses.reduce((sum, c) => sum + c.absent, 0);

  const getAttendanceBadge = (percentage: number) => {
    if (percentage >= 90) return { text: 'Excellent', variant: 'success' as const };
    if (percentage >= 75) return { text: 'Good', variant: 'warning' as const };
    return { text: 'At Risk', variant: 'danger' as const };
  };

  const badge = getAttendanceBadge(overallAttendance);

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="student" onLogout={onLogout} userName="John Doe" userId="STU-001" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar showSearch={false} />
        
        <div className="flex-1 overflow-y-auto p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">Attendance Overview</h1>
            <p className="text-gray-500">Track your attendance across all courses</p>
          </div>

          {/* Overall Attendance */}
          <div className="bg-white rounded-xl border border-gray-200 p-8 mb-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-8">
              <div className="flex items-center gap-8">
                <div>
                  <div className="text-6xl font-semibold text-gray-900 mb-2">{overallAttendance}%</div>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-500">Overall Attendance</span>
                    <Badge variant={badge.variant}>{badge.text}</Badge>
                  </div>
                </div>
              </div>
              
              <div className="flex gap-8">
                <div className="text-center">
                  <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mb-2">
                    <span className="text-2xl font-semibold text-green-600">{totalPresent}</span>
                  </div>
                  <p className="text-sm text-gray-600">Present</p>
                </div>
                <div className="text-center">
                  <div className="w-20 h-20 rounded-full bg-red-100 flex items-center justify-center mb-2">
                    <span className="text-2xl font-semibold text-red-600">{totalAbsent}</span>
                  </div>
                  <p className="text-sm text-gray-600">Absent</p>
                </div>
              </div>
            </div>
          </div>

          {/* Courses Section */}
          <div className="bg-white rounded-xl border border-gray-200 p-8 mb-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">Courses</h3>
            <div className="space-y-6">
              {courses.map((course, index) => (
                <div key={index}>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-gray-900">{course.name}</h4>
                    <span className="text-sm font-semibold text-gray-900">{course.attendance}% Present</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex-1 bg-gray-100 rounded-full h-3 overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${
                          course.attendance >= 90 ? 'bg-green-500' : 
                          course.attendance >= 75 ? 'bg-yellow-500' : 
                          'bg-red-500'
                        }`}
                        style={{ width: `${course.attendance}%` }}
                      />
                    </div>
                    <span className="text-sm text-gray-500 min-w-[100px]">
                      {course.present}/{course.total} classes
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-xl border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-900">Recent Activity</h3>
                <div className="flex gap-2">
                  <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg text-sm transition-colors">
                    <Filter className="w-4 h-4" />
                    Filter by Date
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg text-sm transition-colors">
                    <Download className="w-4 h-4" />
                    Export Report
                  </button>
                </div>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-gray-200 bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Course</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {recentActivity.map((activity, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm text-gray-900">{activity.date}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{activity.course}</td>
                      <td className="px-6 py-4">
                        <Badge 
                          variant={
                            activity.status === 'Present' ? 'present' : 
                            activity.status === 'Absent' ? 'absent' : 
                            'tardy'
                          }
                        >
                          {activity.status}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentAttendance;
