import { useState } from 'react';
import Sidebar from '../Sidebar';
import TopBar from '../TopBar';
import { ScanLine, MapPin, QrCode, CheckCircle } from 'lucide-react';

interface StudentScanProps {
  onLogout: () => void;
}

const StudentScan = ({ onLogout }: StudentScanProps) => {
  const [scanState, setScanState] = useState<'ready' | 'scanning' | 'success'>('ready');

  const handleScan = () => {
    setScanState('scanning');
    setTimeout(() => {
      setScanState('success');
    }, 2000);
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="student" onLogout={onLogout} userName="John Doe" userId="STU-001" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar showSearch={false} />
        
        <div className="flex-1 overflow-y-auto p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">Attendance Scanning</h1>
            <p className="text-gray-500">Scan the QR code to mark your attendance</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Main Area - Camera Feed */}
            <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">QR Code Scanner</h3>
              
              {/* Scanner Area */}
              <div className="relative bg-gray-900 rounded-xl overflow-hidden aspect-video flex items-center justify-center">
                {/* Scan Frame */}
                <div className="relative w-80 h-80">
                  <div className="absolute inset-0 border-4 border-dashed border-green-400 rounded-2xl animate-pulse" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    {scanState === 'ready' && (
                      <ScanLine className="w-32 h-32 text-green-400" />
                    )}
                    {scanState === 'scanning' && (
                      <div className="text-center">
                        <QrCode className="w-32 h-32 text-green-400 animate-pulse mx-auto mb-4" />
                        <p className="text-white text-lg">Scanning...</p>
                      </div>
                    )}
                    {scanState === 'success' && (
                      <div className="text-center">
                        <CheckCircle className="w-32 h-32 text-green-400 mx-auto mb-4" />
                        <p className="text-white text-lg">Scan Successful!</p>
                      </div>
                    )}
                  </div>
                  
                  {/* Corner Markers */}
                  <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-green-500 rounded-tl-lg" />
                  <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-green-500 rounded-tr-lg" />
                  <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-green-500 rounded-bl-lg" />
                  <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-green-500 rounded-br-lg" />
                </div>
              </div>

              <div className="mt-6 text-center">
                <p className="text-sm text-gray-600 mb-4">
                  Position the QR code within the frame to scan
                </p>
                {scanState === 'ready' && (
                  <button
                    onClick={handleScan}
                    className="px-8 py-3 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors font-medium"
                  >
                    Start Scanning
                  </button>
                )}
                {scanState === 'success' && (
                  <button
                    onClick={() => setScanState('ready')}
                    className="px-8 py-3 bg-gray-500 hover:bg-gray-600 text-white rounded-lg transition-colors font-medium"
                  >
                    Scan Another
                  </button>
                )}
              </div>
            </div>

            {/* Right Panel - Status */}
            <div className="space-y-4">
              {/* Location Status */}
              <div className={`bg-white rounded-xl border-2 p-6 ${
                scanState === 'success' ? 'border-green-500' : 'border-gray-200'
              }`}>
                <div className="flex items-start gap-3 mb-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    scanState === 'success' ? 'bg-green-100' : 'bg-gray-100'
                  }`}>
                    <MapPin className={`w-6 h-6 ${
                      scanState === 'success' ? 'text-green-600' : 'text-gray-400'
                    }`} />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">Location Verified</h4>
                    <p className="text-sm text-gray-600">
                      {scanState === 'success' 
                        ? 'You are within the designated area.'
                        : 'Waiting for location verification...'}
                    </p>
                  </div>
                </div>
                {scanState === 'success' && (
                  <div className="flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle className="w-4 h-4" />
                    <span>Verified</span>
                  </div>
                )}
              </div>

              {/* QR Scan Status */}
              <div className={`bg-white rounded-xl border-2 p-6 ${
                scanState === 'success' ? 'border-green-500' : 'border-gray-200'
              }`}>
                <div className="flex items-start gap-3 mb-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    scanState === 'success' ? 'bg-green-100' : 'bg-gray-100'
                  }`}>
                    <QrCode className={`w-6 h-6 ${
                      scanState === 'success' ? 'text-green-600' : 'text-gray-400'
                    }`} />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">QR Code Status</h4>
                    <p className="text-sm text-gray-600">
                      {scanState === 'ready' && 'Ready to scan'}
                      {scanState === 'scanning' && 'Scanning in progress...'}
                      {scanState === 'success' && 'QR Scanned Successfully'}
                    </p>
                  </div>
                </div>
                {scanState === 'success' && (
                  <div className="flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle className="w-4 h-4" />
                    <span>Scanned</span>
                  </div>
                )}
              </div>

              {/* Recording Status */}
              {scanState === 'success' && (
                <div className="bg-green-500 rounded-xl p-6 text-white">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                      <CheckCircle className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">Attendance Recorded Successfully!</h4>
                      <p className="text-sm text-green-100">
                        Your attendance for Computer Science 101 has been marked.
                      </p>
                      <div className="mt-3 pt-3 border-t border-white/20">
                        <p className="text-xs text-green-100">
                          Date: November 28, 2024<br />
                          Time: 10:15 AM
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Instructions */}
              {scanState === 'ready' && (
                <div className="bg-blue-50 rounded-xl border border-blue-200 p-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Instructions</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-start gap-2">
                      <span className="text-blue-600 mt-0.5">•</span>
                      <span>Make sure you are within the classroom area</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-blue-600 mt-0.5">•</span>
                      <span>Position the QR code within the scan frame</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-blue-600 mt-0.5">•</span>
                      <span>Hold steady until scan completes</span>
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentScan;
