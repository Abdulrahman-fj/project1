import { useState } from 'react';
import Sidebar from '../Sidebar';
import TopBar from '../TopBar';
import StatCard from '../StatCard';
import Badge from '../Badge';
import DataTable from '../DataTable';
import { Calendar, AlertCircle, Clock } from 'lucide-react';

interface StudentReportsProps {
  onLogout: () => void;
}

const StudentReports = ({ onLogout }: StudentReportsProps) => {
  const [filters, setFilters] = useState({
    dateFrom: '',
    dateTo: '',
    course: 'all',
  });

  const reportData = [
    { date: '2024-11-28', course: 'Computer Science 101', status: 'Present', notes: '' },
    { date: '2024-11-28', course: 'Data Structures', status: 'Present', notes: '' },
    { date: '2024-11-27', course: 'Advanced Algorithms', status: 'Present', notes: '' },
    { date: '2024-11-27', course: 'Software Engineering', status: 'Absent', notes: 'Medical excuse uploaded' },
    { date: '2024-11-26', course: 'Database Systems', status: 'Present', notes: '' },
    { date: '2024-11-26', course: 'Computer Science 101', status: 'Tardy', notes: 'Arrived 10 mins late' },
  ];

  const columns = [
    { key: 'date', label: 'Date' },
    { key: 'course', label: 'Course' },
    {
      key: 'status',
      label: 'Status',
      render: (value: string) => (
        <Badge 
          variant={
            value === 'Present' ? 'present' : 
            value === 'Absent' ? 'absent' : 
            'tardy'
          }
        >
          {value}
        </Badge>
      ),
    },
    { 
      key: 'notes', 
      label: 'Notes',
      render: (value: string) => (
        <span className="text-sm text-gray-500">{value || '—'}</span>
      ),
    },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="student" onLogout={onLogout} userName="John Doe" userId="STU-001" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar showSearch={false} />
        
        <div className="flex-1 overflow-y-auto p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">Personal Reports</h1>
            <p className="text-gray-500">Detailed attendance records and statistics</p>
          </div>

          {/* Summary Tiles */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <StatCard
              title="Overall Attendance"
              value="92%"
              subtitle="Excellent performance"
              icon={Calendar}
            />
            <StatCard
              title="Total Absences"
              value="8"
              subtitle="This semester"
              icon={AlertCircle}
            />
            <StatCard
              title="Total Late"
              value="3"
              subtitle="This semester"
              icon={Clock}
            />
          </div>

          {/* Filters */}
          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <input
                type="date"
                value={filters.dateFrom}
                onChange={(e) => setFilters({ ...filters, dateFrom: e.target.value })}
                placeholder="From date"
                className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <input
                type="date"
                value={filters.dateTo}
                onChange={(e) => setFilters({ ...filters, dateTo: e.target.value })}
                placeholder="To date"
                className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <select
                value={filters.course}
                onChange={(e) => setFilters({ ...filters, course: e.target.value })}
                className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="all">All Courses</option>
                <option value="CS101">Computer Science 101</option>
                <option value="ALGO">Advanced Algorithms</option>
                <option value="DS">Data Structures</option>
                <option value="DB">Database Systems</option>
                <option value="SE">Software Engineering</option>
              </select>
              <div className="flex gap-2">
                <button className="flex-1 px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm transition-colors">
                  Apply Filters
                </button>
                <button className="px-4 py-2 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg text-sm transition-colors">
                  Reset
                </button>
              </div>
            </div>
          </div>

          {/* Reports Table */}
          <DataTable columns={columns} data={reportData} />
        </div>
      </div>
    </div>
  );
};

export default StudentReports;
