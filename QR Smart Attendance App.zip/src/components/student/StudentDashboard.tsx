import { Link } from 'react-router-dom';
import Sidebar from '../Sidebar';
import TopBar from '../TopBar';
import { ScanLine, Upload, Bell, TrendingUp } from 'lucide-react';

interface StudentDashboardProps {
  onLogout: () => void;
}

const StudentDashboard = ({ onLogout }: StudentDashboardProps) => {
  const subjects = [
    { name: 'Computer Science 101', attendance: 98, color: 'bg-green-500' },
    { name: 'Advanced Algorithms', attendance: 95, color: 'bg-green-400' },
    { name: 'Data Structures', attendance: 92, color: 'bg-green-400' },
    { name: 'Database Systems', attendance: 88, color: 'bg-yellow-500' },
    { name: 'Software Engineering', attendance: 85, color: 'bg-yellow-500' },
  ];

  const notifications = [
    { title: 'New class schedule', time: '2 hours ago', type: 'info' },
    { title: 'Low attendance warning - Database Systems', time: 'Yesterday', type: 'warning' },
    { title: 'Assignment due tomorrow', time: '2 days ago', type: 'alert' },
  ];

  const overallAttendance = 92;

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="student" onLogout={onLogout} userName="John Doe" userId="STU-001" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar searchPlaceholder="Search courses..." />
        
        <div className="flex-1 overflow-y-auto p-8">
          {/* Welcome Section */}
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">Welcome, John! 👋</h1>
            <p className="text-gray-500">Here's your attendance overview</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Attendance Summary Card */}
            <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 p-8">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-1">Attendance Summary</h2>
                  <p className="text-sm text-gray-500">Your overall performance this semester</p>
                </div>
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>

              <div className="flex flex-col items-center mb-8">
                {/* Circular Progress */}
                <div className="relative w-48 h-48 mb-4">
                  <svg className="w-48 h-48 transform -rotate-90">
                    <circle
                      cx="96"
                      cy="96"
                      r="88"
                      stroke="#f0f0f0"
                      strokeWidth="16"
                      fill="none"
                    />
                    <circle
                      cx="96"
                      cy="96"
                      r="88"
                      stroke="#22c55e"
                      strokeWidth="16"
                      fill="none"
                      strokeDasharray={`${2 * Math.PI * 88}`}
                      strokeDashoffset={`${2 * Math.PI * 88 * (1 - overallAttendance / 100)}`}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-5xl font-semibold text-gray-900">{overallAttendance}%</span>
                    <span className="text-sm text-gray-500">Overall</span>
                  </div>
                </div>
                <p className="text-green-600 font-medium">Keep up the great work!</p>
              </div>

              {/* Scan QR CTA */}
              <Link
                to="/student/scan"
                className="w-full py-4 px-6 bg-green-500 hover:bg-green-600 text-white rounded-xl transition-colors flex items-center justify-center gap-3 font-medium text-lg"
              >
                <ScanLine className="w-6 h-6" />
                Scan QR Code
              </Link>
            </div>

            {/* Right Panel */}
            <div className="space-y-6">
              {/* Notifications */}
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Bell className="w-5 h-5 text-gray-600" />
                  <h3 className="font-semibold text-gray-900">Notifications</h3>
                </div>
                <div className="space-y-3">
                  {notifications.map((notif, index) => (
                    <div key={index} className="pb-3 border-b border-gray-100 last:border-0 last:pb-0">
                      <p className="text-sm font-medium text-gray-900 mb-1">{notif.title}</p>
                      <p className="text-xs text-gray-500">{notif.time}</p>
                    </div>
                  ))}
                </div>
                <Link to="/student/notifications" className="text-sm text-green-600 hover:text-green-700 mt-4 block text-center">
                  View All
                </Link>
              </div>

              {/* Submit Documents */}
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Upload className="w-5 h-5 text-gray-600" />
                  <h3 className="font-semibold text-gray-900">Submit Documents</h3>
                </div>
                <p className="text-sm text-gray-600 mb-4">
                  Upload medical reports or absence justifications (.png, .jpg, .pdf)
                </p>
                <button className="w-full py-2 px-4 border-2 border-dashed border-gray-300 hover:border-green-500 rounded-lg text-sm text-gray-600 hover:text-green-600 transition-colors">
                  Click to Upload
                </button>
              </div>
            </div>
          </div>

          {/* Subjects List */}
          <div className="bg-white rounded-xl border border-gray-200 p-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">Subjects</h3>
            <div className="space-y-4">
              {subjects.map((subject, index) => (
                <div key={index} className="group">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-gray-900">{subject.name}</h4>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-semibold text-gray-900">{subject.attendance}%</span>
                      <button className="text-sm text-green-600 hover:text-green-700 opacity-0 group-hover:opacity-100 transition-opacity">
                        View details
                      </button>
                    </div>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                    <div 
                      className={`h-full ${subject.color} rounded-full transition-all`}
                      style={{ width: `${subject.attendance}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
