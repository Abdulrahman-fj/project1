import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  icon?: LucideIcon;
  subtitle?: string;
}

const StatCard = ({ title, value, change, changeType = 'neutral', icon: Icon, subtitle }: StatCardProps) => {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <p className="text-sm text-gray-500 mb-1">{title}</p>
          <p className="text-3xl font-semibold text-gray-900">{value}</p>
        </div>
        {Icon && (
          <div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center">
            <Icon className="w-5 h-5 text-green-600" />
          </div>
        )}
      </div>
      {(change || subtitle) && (
        <div className="flex items-center gap-2">
          {change && (
            <span
              className={`text-sm ${
                changeType === 'positive'
                  ? 'text-green-600'
                  : changeType === 'negative'
                  ? 'text-red-600'
                  : 'text-gray-600'
              }`}
            >
              {change}
            </span>
          )}
          {subtitle && (
            <span className="text-sm text-gray-500">{subtitle}</span>
          )}
        </div>
      )}
    </div>
  );
};

export default StatCard;
