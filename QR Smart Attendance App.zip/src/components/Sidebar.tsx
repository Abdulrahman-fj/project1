import { Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, CheckSquare, FileText, Bell, Users, BarChart3, User, Settings, LogOut, QrCode, ScanLine } from 'lucide-react';

interface SidebarProps {
  role: 'admin' | 'professor' | 'student';
  onLogout: () => void;
  userName: string;
  userAvatar?: string;
  userId?: string;
}

const Sidebar = ({ role, onLogout, userName, userAvatar, userId }: SidebarProps) => {
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    onLogout();
    navigate('/login');
  };

  const adminMenuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/admin/dashboard' },
    { icon: Bell, label: 'Notifications', path: '/admin/notifications' },
    { icon: Users, label: 'User Management', path: '/admin/users' },
    { icon: BarChart3, label: 'System Analytics', path: '/admin/analytics' },
    { icon: User, label: 'Profile', path: '/admin/profile' },
    { icon: Settings, label: 'Settings', path: '/admin/settings' },
  ];

  const professorMenuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/professor/dashboard' },
    { icon: CheckSquare, label: 'Attendance', path: '/professor/attendance' },
    { icon: QrCode, label: 'Generate QR Code', path: '/professor/qr' },
    { icon: FileText, label: 'Reports', path: '/professor/reports' },
    { icon: Bell, label: 'Notifications', path: '/professor/notifications' },
    { icon: User, label: 'Profile', path: '/professor/profile' },
    { icon: Settings, label: 'Settings', path: '/professor/settings' },
  ];

  const studentMenuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/student/dashboard' },
    { icon: CheckSquare, label: 'Attendance', path: '/student/attendance' },
    { icon: FileText, label: 'Reports', path: '/student/reports' },
    { icon: Bell, label: 'Notifications', path: '/student/notifications' },
    { icon: User, label: 'Profile', path: '/student/profile' },
    { icon: ScanLine, label: 'QR Code Scanner', path: '/student/scan' },
    { icon: Settings, label: 'Settings', path: '/student/settings' },
  ];

  const menuItems = role === 'admin' ? adminMenuItems : role === 'professor' ? professorMenuItems : studentMenuItems;

  return (
    <div className="w-64 bg-white h-screen border-r border-gray-200 flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
            <QrCode className="w-5 h-5 text-white" />
          </div>
          <span className="font-semibold text-gray-900">Smart Attendance</span>
        </div>
      </div>

      {/* Menu Section */}
      <div className="flex-1 overflow-y-auto py-4">
        <div className="px-3">
          <p className="text-xs text-gray-500 px-3 mb-2">MENU</p>
          <nav className="space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                    isActive
                      ? 'bg-green-50 text-green-600'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-sm">{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Logout */}
      <div className="border-t border-gray-200 p-3">
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-gray-600 hover:bg-gray-50 w-full transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="text-sm">Logout</span>
        </button>
      </div>

      {/* User Info */}
      <div className="border-t border-gray-200 p-4">
        <div className="flex items-center gap-3">
          {userAvatar ? (
            <img src={userAvatar} alt={userName} className="w-10 h-10 rounded-full" />
          ) : (
            <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
              <span className="text-green-600 font-semibold text-sm">
                {userName.charAt(0)}
              </span>
            </div>
          )}
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-gray-900 truncate">{userName}</p>
            <p className="text-xs text-gray-500 capitalize">{role === 'admin' ? 'Administrator' : role}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
