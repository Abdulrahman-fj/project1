import { useState } from 'react';
import Sidebar from '../Sidebar';
import TopBar from '../TopBar';
import { Search, UserPlus, AlertTriangle, CheckCircle, MoreVertical } from 'lucide-react';

interface AdminNotificationsProps {
  onLogout: () => void;
}

const AdminNotifications = ({ onLogout }: AdminNotificationsProps) => {
  const [activeTab, setActiveTab] = useState<'all' | 'system' | 'requests' | 'unread'>('all');

  const notifications = [
    {
      id: 1,
      type: 'user',
      icon: UserPlus,
      iconColor: 'text-green-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
      title: 'New User Registration',
      description: 'Jane Doe has requested an account with student privileges. Review and approve their request.',
      time: '5m ago',
      unread: true,
    },
    {
      id: 2,
      type: 'system',
      icon: AlertTriangle,
      iconColor: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
      borderColor: 'border-yellow-200',
      title: 'System Alert: High CPU Usage',
      description: 'Server CPU usage has exceeded 90% for the last 15 minutes. Performance may be degraded.',
      time: '30m ago',
      unread: true,
    },
    {
      id: 3,
      type: 'system',
      icon: CheckCircle,
      iconColor: 'text-gray-600',
      bgColor: 'bg-gray-50',
      borderColor: 'border-gray-200',
      title: 'Database Backup Successful',
      description: 'The daily database backup completed successfully without any errors.',
      time: '2h ago',
      unread: false,
    },
    {
      id: 4,
      type: 'user',
      icon: UserPlus,
      iconColor: 'text-green-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
      title: 'New User Registration',
      description: 'John Smith has requested an account with teacher privileges. You approved the request.',
      time: 'Yesterday',
      unread: false,
    },
  ];

  const filteredNotifications = notifications.filter((notif) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'system') return notif.type === 'system';
    if (activeTab === 'requests') return notif.type === 'user';
    if (activeTab === 'unread') return notif.unread;
    return true;
  });

  const tabs = [
    { id: 'all', label: 'All' },
    { id: 'system', label: 'System Alerts' },
    { id: 'requests', label: 'User Requests' },
    { id: 'unread', label: 'Unread' },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="admin" onLogout={onLogout} userName="Admin Name" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar showSearch={false} />
        
        <div className="flex-1 overflow-y-auto p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">Notification Center</h1>
            <p className="text-gray-500">View and manage all system alerts and user notifications.</p>
          </div>

          {/* Controls */}
          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="relative flex-1 max-w-md w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search notifications..."
                  className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div className="flex gap-2">
                <button className="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm transition-colors">
                  Mark All as Read
                </button>
                <button className="px-4 py-2 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg text-sm transition-colors">
                  Archive All
                </button>
              </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-2 mt-6 border-b border-gray-200">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-4 py-2 text-sm font-medium transition-colors relative ${
                    activeTab === tab.id
                      ? 'text-green-600'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {tab.label}
                  {activeTab === tab.id && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-green-500" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Notifications List */}
          <div className="space-y-4">
            {filteredNotifications.map((notification) => {
              const Icon = notification.icon;
              return (
                <div
                  key={notification.id}
                  className={`bg-white rounded-xl border-2 ${notification.borderColor} p-6 hover:shadow-md transition-shadow ${
                    notification.unread ? 'border-l-4' : ''
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-10 h-10 ${notification.bgColor} rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <Icon className={`w-5 h-5 ${notification.iconColor}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-4 mb-2">
                        <h3 className="font-semibold text-gray-900">{notification.title}</h3>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-500">{notification.time}</span>
                          <button className="p-1 hover:bg-gray-100 rounded">
                            <MoreVertical className="w-4 h-4 text-gray-400" />
                          </button>
                        </div>
                      </div>
                      <p className="text-sm text-gray-600">{notification.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminNotifications;
