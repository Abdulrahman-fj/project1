import { useState } from 'react';
import Sidebar from '../Sidebar';
import TopBar from '../TopBar';
import Badge from '../Badge';
import DataTable from '../DataTable';
import { Download, UserPlus, Filter, Edit, Trash2, ToggleLeft } from 'lucide-react';

interface AdminUsersProps {
  onLogout: () => void;
}

const AdminUsers = ({ onLogout }: AdminUsersProps) => {
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  const users = [
    { id: 'USR-001', name: 'John Doe', email: 'john.doe@university.edu', role: 'Student', status: 'Active' },
    { id: 'USR-002', name: 'Jane Smith', email: 'jane.smith@university.edu', role: 'Professor', status: 'Active' },
    { id: 'USR-003', name: 'Bob Johnson', email: 'bob.j@university.edu', role: 'Admin', status: 'Active' },
    { id: 'USR-004', name: 'Alice Williams', email: 'alice.w@university.edu', role: 'Student', status: 'Inactive' },
    { id: 'USR-005', name: 'Charlie Brown', email: 'charlie.b@university.edu', role: 'Professor', status: 'Active' },
    { id: 'USR-006', name: 'Diana Prince', email: 'diana.p@university.edu', role: 'Student', status: 'Active' },
    { id: 'USR-007', name: 'Eve Anderson', email: 'eve.a@university.edu', role: 'Student', status: 'Pending' },
    { id: 'USR-008', name: 'Frank Miller', email: 'frank.m@university.edu', role: 'Professor', status: 'Active' },
  ];

  const filteredUsers = users.filter((user) => {
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    const matchesStatus = statusFilter === 'all' || user.status === statusFilter;
    return matchesRole && matchesStatus;
  });

  const columns = [
    { key: 'id', label: 'User ID' },
    { key: 'name', label: 'Name' },
    { key: 'email', label: 'Email' },
    {
      key: 'role',
      label: 'Role',
      render: (value: string) => (
        <Badge variant={value === 'Admin' ? 'info' : value === 'Professor' ? 'warning' : 'default'}>
          {value}
        </Badge>
      ),
    },
    {
      key: 'status',
      label: 'Status',
      render: (value: string) => (
        <Badge variant={value === 'Active' ? 'active' : value === 'Inactive' ? 'inactive' : 'warning'}>
          {value}
        </Badge>
      ),
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_: any, row: any) => (
        <div className="flex items-center gap-2">
          <button className="p-1 hover:bg-gray-100 rounded transition-colors" title="Edit">
            <Edit className="w-4 h-4 text-gray-600" />
          </button>
          <button className="p-1 hover:bg-gray-100 rounded transition-colors" title="Toggle Status">
            <ToggleLeft className="w-4 h-4 text-gray-600" />
          </button>
          <button className="p-1 hover:bg-gray-100 rounded transition-colors" title="Delete">
            <Trash2 className="w-4 h-4 text-red-600" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="admin" onLogout={onLogout} userName="Admin Name" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar showSearch={false} />
        
        <div className="flex-1 overflow-y-auto p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-semibold text-gray-900 mb-2">User Management</h1>
              <p className="text-gray-500">Manage all users across the platform</p>
            </div>
            <div className="flex gap-3">
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg transition-colors">
                <Download className="w-4 h-4" />
                Export
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors">
                <UserPlus className="w-4 h-4" />
                Add New User
              </button>
            </div>
          </div>

          {/* Filters */}
          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
            <div className="flex flex-wrap items-center gap-4">
              <input
                type="text"
                placeholder="Search by name, ID, or email..."
                className="flex-1 min-w-[250px] px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="all">All Roles</option>
                <option value="Student">Student</option>
                <option value="Professor">Professor</option>
                <option value="Admin">Admin</option>
              </select>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="all">All Status</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Pending">Pending</option>
              </select>
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg transition-colors">
                <Filter className="w-4 h-4" />
                More Filters
              </button>
            </div>
          </div>

          {/* Users Table */}
          <DataTable columns={columns} data={filteredUsers} />
        </div>
      </div>
    </div>
  );
};

export default AdminUsers;
