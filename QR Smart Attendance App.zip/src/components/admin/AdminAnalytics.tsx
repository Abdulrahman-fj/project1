import Sidebar from '../Sidebar';
import TopBar from '../TopBar';
import StatCard from '../StatCard';
import { Activity, Users, CheckCircle, Server } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface AdminAnalyticsProps {
  onLogout: () => void;
}

const AdminAnalytics = ({ onLogout }: AdminAnalyticsProps) => {
  // Mock data for charts
  const attendanceOverTime = [
    { date: 'Nov 1', attendance: 88 },
    { date: 'Nov 5', attendance: 90 },
    { date: 'Nov 10', attendance: 87 },
    { date: 'Nov 15', attendance: 92 },
    { date: 'Nov 20', attendance: 89 },
    { date: 'Nov 25', attendance: 91 },
    { date: 'Nov 28', attendance: 93 },
  ];

  const scanOutcomes = [
    { name: 'Success', value: 8456 },
    { name: 'Failed', value: 234 },
  ];

  const COLORS = ['#22c55e', '#ef4444'];

  const activityLog = [
    { time: '2024-11-28 14:35', user: 'Prof. John Smith', action: 'Generated QR code', ip: '192.168.1.45' },
    { time: '2024-11-28 14:20', user: 'Admin Mary Johnson', action: 'Created new class', ip: '192.168.1.12' },
    { time: '2024-11-28 14:10', user: 'Student Alice Brown', action: 'Updated profile', ip: '192.168.1.87' },
    { time: '2024-11-28 13:55', user: 'Prof. David Lee', action: 'Generated QR code', ip: '192.168.1.34' },
    { time: '2024-11-28 13:40', user: 'Admin Sarah Wilson', action: 'Added new user', ip: '192.168.1.12' },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="admin" onLogout={onLogout} userName="Admin Name" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar showSearch={false} />
        
        <div className="flex-1 overflow-y-auto p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">System Analytics</h1>
            <p className="text-gray-500">Monitor system performance and user activity</p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatCard
              title="Overall Attendance"
              value="91.2%"
              change="+2.3% this week"
              changeType="positive"
              icon={Activity}
            />
            <StatCard
              title="Total Active Users"
              value="1,328"
              subtitle="Across all roles"
              icon={Users}
            />
            <StatCard
              title="QR Scan Success Rate"
              value="97.3%"
              change="+0.8% today"
              changeType="positive"
              icon={CheckCircle}
            />
            <StatCard
              title="System Health"
              value="Online"
              subtitle="99.9% uptime"
              icon={Server}
            />
          </div>

          {/* Dark Analytics Section */}
          <div className="bg-gray-900 rounded-2xl p-8 mb-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Attendance Over Time */}
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">Attendance Over Time</h3>
                <p className="text-gray-400 text-sm mb-6">Last 30 days performance</p>
                <ResponsiveContainer width="100%" height={280}>
                  <LineChart data={attendanceOverTime}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="date" tick={{ fill: '#9ca3af', fontSize: 12 }} stroke="#374151" />
                    <YAxis tick={{ fill: '#9ca3af', fontSize: 12 }} stroke="#374151" domain={[80, 100]} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1f2937',
                        border: '1px solid #374151',
                        borderRadius: '8px',
                        color: '#fff',
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="attendance" 
                      stroke="#22c55e" 
                      strokeWidth={3}
                      dot={{ fill: '#22c55e', r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Scan Outcomes */}
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">Scan Outcomes</h3>
                <p className="text-gray-400 text-sm mb-6">Total scans breakdown</p>
                <div className="flex items-center justify-center">
                  <ResponsiveContainer width="100%" height={280}>
                    <PieChart>
                      <Pie
                        data={scanOutcomes}
                        cx="50%"
                        cy="50%"
                        innerRadius={80}
                        outerRadius={120}
                        fill="#8884d8"
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {scanOutcomes.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#1f2937',
                          border: '1px solid #374151',
                          borderRadius: '8px',
                          color: '#fff',
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-6 mt-4">
                  {scanOutcomes.map((item, index) => (
                    <div key={item.name} className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index] }} />
                      <span className="text-gray-300 text-sm">{item.name}: {item.value.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* System Activity Log */}
          <div className="bg-white rounded-xl border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h3 className="font-semibold text-gray-900">System Activity Log</h3>
              <p className="text-sm text-gray-500 mt-1">Recent system actions and events</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-gray-200 bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Date/Time</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">IP Address</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {activityLog.map((log, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm text-gray-900">{log.time}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{log.user}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{log.action}</td>
                      <td className="px-6 py-4 text-sm text-gray-500 font-mono">{log.ip}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="p-4 border-t border-gray-200 flex justify-center">
              <button className="text-sm text-green-600 hover:text-green-700">Load More</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminAnalytics;
