import Sidebar from '../Sidebar';
import TopBar from '../TopBar';
import { Camera } from 'lucide-react';

interface AdminProfileProps {
  onLogout: () => void;
}

const AdminProfile = ({ onLogout }: AdminProfileProps) => {
  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="admin" onLogout={onLogout} userName="Admin Name" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar showSearch={false} />
        
        <div className="flex-1 overflow-y-auto p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">Profile</h1>
            <p className="text-gray-500">Manage your personal information</p>
          </div>

          {/* Profile Card */}
          <div className="max-w-3xl">
            <div className="bg-white rounded-xl border border-gray-200 p-8">
              {/* Profile Picture */}
              <div className="flex items-start gap-6 mb-8 pb-8 border-b border-gray-200">
                <div className="relative">
                  <div className="w-24 h-24 rounded-full bg-green-100 flex items-center justify-center">
                    <span className="text-3xl font-semibold text-green-600">A</span>
                  </div>
                  <button className="absolute bottom-0 right-0 w-8 h-8 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center transition-colors">
                    <Camera className="w-4 h-4 text-white" />
                  </button>
                </div>
                <div className="flex-1">
                  <h2 className="text-xl font-semibold text-gray-900 mb-1">Admin Name</h2>
                  <p className="text-gray-500 mb-4">System Administrator</p>
                  <button className="px-4 py-2 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg text-sm transition-colors">
                    Change Photo
                  </button>
                </div>
              </div>

              {/* Profile Information */}
              <form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-900 mb-2">
                      Full Name
                    </label>
                    <input
                      type="text"
                      defaultValue="Admin Name"
                      className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-900 mb-2">
                      Admin ID
                    </label>
                    <input
                      type="text"
                      defaultValue="ADM-001"
                      disabled
                      className="w-full px-4 py-2 bg-gray-100 border border-gray-200 rounded-lg text-sm text-gray-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-900 mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      defaultValue="admin@university.edu"
                      className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-900 mb-2">
                      Contact Number
                    </label>
                    <input
                      type="tel"
                      defaultValue="+1 (555) 123-4567"
                      className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-2">
                    Bio
                  </label>
                  <textarea
                    rows={4}
                    defaultValue="System administrator with 5+ years of experience managing educational platforms."
                    className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-4">
                  <button
                    type="submit"
                    className="px-6 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors"
                  >
                    Update Profile
                  </button>
                  <button
                    type="button"
                    className="px-6 py-2 border border-green-500 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                  >
                    Change Password
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminProfile;
