import Sidebar from '../Sidebar';
import TopBar from '../TopBar';
import StatCard from '../StatCard';
import Badge from '../Badge';
import { Users, GraduationCap, TrendingUp, AlertCircle, ChevronRight } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface AdminDashboardProps {
  onLogout: () => void;
}

const AdminDashboard = ({ onLogout }: AdminDashboardProps) => {
  // Mock data for charts
  const departmentData = [
    { name: 'Science', attendance: 89 },
    { name: 'Arts', attendance: 92 },
    { name: 'Engineering', attendance: 95 },
    { name: 'Business', attendance: 87 },
    { name: 'Medicine', attendance: 91 },
    { name: 'Law', attendance: 88 },
  ];

  const lowAttendanceCourses = [
    { course: 'Computer Science 101', department: 'Engineering', professor: 'Prof. Turing', attendance: 65 },
    { course: 'History of Art', department: 'Arts', professor: 'Prof. Da Vinci', attendance: 71 },
    { course: 'Business Management', department: 'Business', professor: 'Prof. Drucker', attendance: 74 },
  ];

  const professorsAndStudents = [
    { professor: 'Dr. Alan Turing', professorId: 'PROF-012', department: 'Engineering', courses: 3 },
    { professor: 'Prof. Marie Curie', professorId: 'PROF-005', department: 'Science', courses: 2 },
    { professor: 'Prof. Peter Drucker', professorId: 'PROF-021', department: 'Business', courses: 4 },
  ];

  const flaggedStudents = [
    { name: 'John Doe', id: 'STU-001', course: 'Computer Science 101', absences: 8, reason: '8 consecutive absences' },
    { name: 'Ada Lovelace', id: 'STU-008', course: 'Advanced Algorithms', absences: 6, reason: '6 absences this month' },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="admin" onLogout={onLogout} userName="Admin Name" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar searchPlaceholder="Search users or courses..." />
        
        <div className="flex-1 overflow-y-auto p-8">
          {/* Welcome Section */}
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">Welcome back, Admin!</h1>
            <p className="text-gray-500">Here's an overview of the system's activity today.</p>
          </div>

          {/* Top Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatCard
              title="Total Students"
              value="1,250"
              change="+1.2% this month"
              changeType="positive"
              icon={Users}
            />
            <StatCard
              title="Active Classes"
              value="32"
              change="+5% from yesterday"
              changeType="positive"
              icon={GraduationCap}
            />
            <StatCard
              title="Overall Attendance Rate"
              value="92.5%"
              change="-0.5% today"
              changeType="negative"
            />
            <StatCard
              title="Total Professors"
              value="48"
              subtitle="Across all departments"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Attendance by Department Chart */}
            <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Attendance Rate by Department</h3>
                  <p className="text-sm text-gray-500">This Week</p>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={departmentData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} domain={[0, 100]} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                      fontSize: '12px'
                    }}
                  />
                  <Bar dataKey="attendance" fill="#22c55e" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Low Attendance Alerts */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900">Low Attendance Alerts</h3>
                <AlertCircle className="w-5 h-5 text-red-500" />
              </div>
              <div className="space-y-4">
                {lowAttendanceCourses.map((course, index) => (
                  <div key={index} className="p-4 bg-red-50 rounded-lg border border-red-100">
                    <h4 className="font-medium text-gray-900 text-sm mb-1">{course.course}</h4>
                    <p className="text-xs text-gray-600 mb-2">{course.professor}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-red-600 font-semibold">{course.attendance}%</span>
                      <button className="text-xs text-green-600 hover:text-green-700 flex items-center gap-1">
                        View details
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
                <button className="w-full py-2 text-sm text-green-600 hover:text-green-700 border border-green-200 rounded-lg hover:bg-green-50 transition-colors">
                  View All
                </button>
              </div>
            </div>
          </div>

          {/* Professors & Students Table */}
          <div className="bg-white rounded-xl border border-gray-200 mb-8">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Professors & Students</h3>
                  <p className="text-sm text-gray-500">Quick overview of faculty and their students</p>
                </div>
                <input
                  type="text"
                  placeholder="Search professors..."
                  className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-gray-200 bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Professor</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Professor ID</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Department</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Courses</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {professorsAndStudents.map((prof, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm text-gray-900">{prof.professor}</td>
                      <td className="px-6 py-4 text-sm text-green-600">{prof.professorId}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{prof.department}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{prof.courses}</td>
                      <td className="px-6 py-4">
                        <button className="text-sm text-green-600 hover:text-green-700 flex items-center gap-1">
                          View Students
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Expanded Student Details (for Dr. Alan Turing) */}
            <div className="bg-gray-50 border-t border-gray-200 p-6">
              <h4 className="text-sm font-medium text-gray-900 mb-4">Enrolled Students for Dr. Alan Turing</h4>
              <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                <table className="w-full">
                  <thead className="border-b border-gray-200 bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Student Name</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Student ID</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Course</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Attendance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    <tr>
                      <td className="px-6 py-3 text-sm text-gray-900">John Doe</td>
                      <td className="px-6 py-3 text-sm text-green-600">STU-001</td>
                      <td className="px-6 py-3 text-sm text-gray-600">Computer Science 101</td>
                      <td className="px-6 py-3"><Badge variant="success">98%</Badge></td>
                    </tr>
                    <tr>
                      <td className="px-6 py-3 text-sm text-gray-900">Ada Lovelace</td>
                      <td className="px-6 py-3 text-sm text-green-600">STU-008</td>
                      <td className="px-6 py-3 text-sm text-gray-600">Advanced Algorithms</td>
                      <td className="px-6 py-3"><Badge variant="success">95%</Badge></td>
                    </tr>
                    <tr>
                      <td className="px-6 py-3 text-sm text-gray-900">Grace Hopper</td>
                      <td className="px-6 py-3 text-sm text-green-600">STU-015</td>
                      <td className="px-6 py-3 text-sm text-gray-600">Advanced Algorithms</td>
                      <td className="px-6 py-3"><Badge variant="warning">82%</Badge></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Flagged Students */}
          <div className="bg-white rounded-xl border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h3 className="font-semibold text-gray-900">Flagged Students - At Risk</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-gray-200 bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Student Name</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Student ID</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Course</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Reason</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {flaggedStudents.map((student, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm text-gray-900">{student.name}</td>
                      <td className="px-6 py-4 text-sm text-green-600">{student.id}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{student.course}</td>
                      <td className="px-6 py-4">
                        <Badge variant="danger">{student.reason}</Badge>
                      </td>
                      <td className="px-6 py-4">
                        <button className="text-sm text-green-600 hover:text-green-700">View Details</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
