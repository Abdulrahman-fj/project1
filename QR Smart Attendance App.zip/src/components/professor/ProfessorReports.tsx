import { useState } from 'react';
import Sidebar from '../Sidebar';
import TopBar from '../TopBar';
import StatCard from '../StatCard';
import Badge from '../Badge';
import DataTable from '../DataTable';
import { TrendingUp, TrendingDown, Download, FileText } from 'lucide-react';

interface ProfessorReportsProps {
  onLogout: () => void;
}

const ProfessorReports = ({ onLogout }: ProfessorReportsProps) => {
  const [filters, setFilters] = useState({
    student: '',
    dateFrom: '',
    dateTo: '',
    course: 'all',
  });

  const reportData = [
    { studentName: 'John Doe', date: '2024-11-28', course: 'CS201', session: 'Lecture 5', status: 'Present' },
    { studentName: 'Jane Smith', date: '2024-11-28', course: 'CS201', session: 'Lecture 5', status: 'Present' },
    { studentName: 'Bob Wilson', date: '2024-11-28', course: 'CS201', session: 'Lecture 5', status: 'Absent' },
    { studentName: 'Alice Johnson', date: '2024-11-27', course: 'MATH301', session: 'Lecture 3', status: 'Present' },
    { studentName: 'Charlie Brown', date: '2024-11-27', course: 'MATH301', session: 'Lecture 3', status: 'Tardy' },
  ];

  const columns = [
    { key: 'studentName', label: 'Student Name' },
    { key: 'date', label: 'Date' },
    { key: 'course', label: 'Course/Session' },
    {
      key: 'status',
      label: 'Status',
      render: (value: string) => (
        <Badge 
          variant={
            value === 'Present' ? 'present' : 
            value === 'Absent' ? 'absent' : 
            'tardy'
          }
        >
          {value}
        </Badge>
      ),
    },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="professor" onLogout={onLogout} userName="Prof. John Smith" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar showSearch={false} />
        
        <div className="flex-1 overflow-y-auto p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">Class Reports</h1>
            <p className="text-gray-500">View and export attendance reports</p>
          </div>

          {/* Top Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <StatCard
              title="Avg. Attendance (Current Course)"
              value="92%"
              change="+3% this week"
              changeType="positive"
              icon={TrendingUp}
            />
            <StatCard
              title="Avg. Attendance (All Courses)"
              value="89%"
              change="-1% this week"
              changeType="negative"
              icon={TrendingDown}
            />
            <StatCard
              title="Total Sessions"
              value="28"
              subtitle="This semester"
              icon={FileText}
            />
          </div>

          {/* Filters */}
          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
              <input
                type="text"
                placeholder="Search by student name"
                value={filters.student}
                onChange={(e) => setFilters({ ...filters, student: e.target.value })}
                className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <input
                type="date"
                value={filters.dateFrom}
                onChange={(e) => setFilters({ ...filters, dateFrom: e.target.value })}
                placeholder="From date"
                className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <input
                type="date"
                value={filters.dateTo}
                onChange={(e) => setFilters({ ...filters, dateTo: e.target.value })}
                placeholder="To date"
                className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <select
                value={filters.course}
                onChange={(e) => setFilters({ ...filters, course: e.target.value })}
                className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="all">All Courses</option>
                <option value="CS201">CS201 – Data Structures</option>
                <option value="MATH301">MATH301 – Advanced Calculus</option>
                <option value="CHEM101">CHEM101 – General Chemistry</option>
              </select>
            </div>
            <div className="flex gap-3">
              <button className="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm transition-colors">
                Apply Filters
              </button>
              <button className="px-4 py-2 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg text-sm transition-colors">
                Reset
              </button>
              <div className="flex-1" />
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg text-sm transition-colors">
                <Download className="w-4 h-4" />
                Download CSV
              </button>
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg text-sm transition-colors">
                <FileText className="w-4 h-4" />
                Export PDF
              </button>
            </div>
          </div>

          {/* Reports Table */}
          <DataTable columns={columns} data={reportData} />
        </div>
      </div>
    </div>
  );
};

export default ProfessorReports;
