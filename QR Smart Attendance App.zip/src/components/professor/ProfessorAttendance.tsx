import { useState } from 'react';
import Sidebar from '../Sidebar';
import TopBar from '../TopBar';
import Badge from '../Badge';
import { Search, ChevronDown } from 'lucide-react';

interface ProfessorAttendanceProps {
  onLogout: () => void;
}

const ProfessorAttendance = ({ onLogout }: ProfessorAttendanceProps) => {
  const [searchTerm, setSearchTerm] = useState('');

  const students = [
    { id: 'STU-001', name: 'John Doe', status: 'Present' },
    { id: 'STU-002', name: 'Jane Smith', status: 'Present' },
    { id: 'STU-003', name: 'Bob Wilson', status: 'Absent' },
    { id: 'STU-004', name: 'Alice Johnson', status: 'Present' },
    { id: 'STU-005', name: 'Charlie Brown', status: 'Tardy' },
    { id: 'STU-006', name: 'Diana Prince', status: 'Present' },
    { id: 'STU-007', name: 'Eve Anderson', status: 'Present' },
    { id: 'STU-008', name: 'Frank Miller', status: 'Absent' },
  ];

  const filteredStudents = students.filter((student) =>
    student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const presentCount = students.filter((s) => s.status === 'Present').length;
  const absentCount = students.filter((s) => s.status === 'Absent').length;
  const tardyCount = students.filter((s) => s.status === 'Tardy').length;

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="professor" onLogout={onLogout} userName="Prof. John Smith" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar showSearch={false} />
        
        <div className="flex-1 overflow-y-auto p-8">
          {/* Header */}
          <div className="flex items-start justify-between mb-8">
            <div>
              <h1 className="text-3xl font-semibold text-gray-900 mb-2">Attendance Management</h1>
              <p className="text-gray-500">CS101 – Intro to Computer Science, Sec 001</p>
            </div>
            <button className="px-6 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors">
              End Session
            </button>
          </div>

          {/* Summary Tiles */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-500">Present</span>
                <div className="w-3 h-3 rounded-full bg-green-500" />
              </div>
              <p className="text-3xl font-semibold text-gray-900">{presentCount}</p>
            </div>
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-500">Absent</span>
                <div className="w-3 h-3 rounded-full bg-red-500" />
              </div>
              <p className="text-3xl font-semibold text-gray-900">{absentCount}</p>
            </div>
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-500">Tardy</span>
                <div className="w-3 h-3 rounded-full bg-yellow-500" />
              </div>
              <p className="text-3xl font-semibold text-gray-900">{tardyCount}</p>
            </div>
          </div>

          {/* Students Table */}
          <div className="bg-white rounded-xl border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-900">Student Attendance</h3>
                <div className="relative max-w-xs">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search students..."
                    className="pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-gray-200 bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Student Name</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Student ID</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredStudents.map((student) => (
                    <tr key={student.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                            <span className="text-sm font-semibold text-green-600">
                              {student.name.charAt(0)}
                            </span>
                          </div>
                          <span className="text-sm text-gray-900">{student.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">{student.id}</td>
                      <td className="px-6 py-4">
                        <Badge 
                          variant={
                            student.status === 'Present' ? 'present' : 
                            student.status === 'Absent' ? 'absent' : 
                            'tardy'
                          }
                        >
                          {student.status}
                        </Badge>
                      </td>
                      <td className="px-6 py-4">
                        <button className="flex items-center gap-2 px-3 py-1.5 border border-gray-200 hover:bg-gray-50 text-sm text-gray-700 rounded-lg transition-colors">
                          Change Status
                          <ChevronDown className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfessorAttendance;
