import { useState } from 'react';
import Sidebar from '../Sidebar';
import TopBar from '../TopBar';
import Badge from '../Badge';
import { QrCode, Users, Calendar } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface ProfessorDashboardProps {
  onLogout: () => void;
}

const ProfessorDashboard = ({ onLogout }: ProfessorDashboardProps) => {
  const [selectedClass, setSelectedClass] = useState<number | null>(0);

  const classes = [
    {
      id: 1,
      code: 'CS201',
      title: 'Data Structures',
      semester: 'Fall 2024',
      image: 'https://images.unsplash.com/photo-1720371144090-8474e0e2f6d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21wdXRlciUyMHNjaWVuY2UlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc2NDI4MDg0Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      nextSession: 'Tomorrow, 10:00 AM',
      students: [
        { id: 'STU-001', name: 'John Doe', avatar: null, status: 'Present' },
        { id: 'STU-002', name: 'Jane Smith', avatar: null, status: 'Present' },
        { id: 'STU-003', name: 'Bob Wilson', avatar: null, status: 'Absent' },
        { id: 'STU-004', name: 'Alice Johnson', avatar: null, status: 'Present' },
      ],
      attendanceRate: 92,
      presentCount: 28,
      absentCount: 2,
    },
    {
      id: 2,
      code: 'MATH301',
      title: 'Advanced Calculus',
      semester: 'Fall 2024',
      image: 'https://images.unsplash.com/photo-1635372722656-389f87a941b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXRoZW1hdGljcyUyMGVxdWF0aW9uc3xlbnwxfHx8fDE3NjQyODg1OTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      nextSession: 'Today, 2:00 PM',
      students: [
        { id: 'STU-005', name: 'Charlie Brown', avatar: null, status: 'Present' },
        { id: 'STU-006', name: 'Diana Prince', avatar: null, status: 'Present' },
      ],
      attendanceRate: 95,
      presentCount: 19,
      absentCount: 1,
    },
    {
      id: 3,
      code: 'CHEM101',
      title: 'General Chemistry',
      semester: 'Fall 2024',
      image: 'https://images.unsplash.com/photo-1631106321638-d94d9a8f3e1f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVtaXN0cnklMjBsYWJvcmF0b3J5fGVufDF8fHx8MTc2NDM1NTExNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      nextSession: 'Monday, 9:00 AM',
      students: [
        { id: 'STU-007', name: 'Eve Anderson', avatar: null, status: 'Present' },
        { id: 'STU-008', name: 'Frank Miller', avatar: null, status: 'Absent' },
      ],
      attendanceRate: 88,
      presentCount: 35,
      absentCount: 5,
    },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="professor" onLogout={onLogout} userName="Prof. John Smith" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar searchPlaceholder="Search classes or students..." />
        
        <div className="flex-1 overflow-y-auto p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">My Classes</h1>
            <p className="text-gray-500">Manage your courses and track student attendance</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Class Cards */}
            <div className="lg:col-span-2">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {classes.map((classItem, index) => (
                  <div
                    key={classItem.id}
                    onClick={() => setSelectedClass(index)}
                    className={`bg-white rounded-xl border-2 overflow-hidden cursor-pointer transition-all hover:shadow-lg ${
                      selectedClass === index ? 'border-green-500' : 'border-gray-200'
                    }`}
                  >
                    <div className="relative h-32 overflow-hidden">
                      <ImageWithFallback
                        src={classItem.image}
                        alt={classItem.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                      <div className="absolute bottom-3 left-4">
                        <h3 className="text-white font-semibold">{classItem.code}</h3>
                      </div>
                    </div>
                    <div className="p-4">
                      <h4 className="font-semibold text-gray-900 mb-1">{classItem.title}</h4>
                      <p className="text-sm text-gray-500 mb-3">{classItem.semester}</p>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Calendar className="w-4 h-4" />
                        <span>{classItem.nextSession}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Class Details Panel */}
            {selectedClass !== null && (
              <div className="bg-white rounded-xl border border-gray-200 p-6 h-fit sticky top-6">
                <div className="mb-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-1">
                    {classes[selectedClass].code} – {classes[selectedClass].title}
                  </h3>
                  <p className="text-sm text-gray-500 mb-4">{classes[selectedClass].nextSession}</p>
                  <button className="w-full py-3 px-4 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors flex items-center justify-center gap-2">
                    <QrCode className="w-5 h-5" />
                    Generate Class QR Code
                  </button>
                </div>

                {/* Quick Stats */}
                <div className="mb-6 pb-6 border-b border-gray-200">
                  <h4 className="text-sm font-medium text-gray-900 mb-3">Quick Stats</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-green-50 rounded-lg p-3">
                      <p className="text-xs text-gray-600 mb-1">Attendance Rate</p>
                      <p className="text-xl font-semibold text-green-600">{classes[selectedClass].attendanceRate}%</p>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3">
                      <p className="text-xs text-gray-600 mb-1">Total Students</p>
                      <p className="text-xl font-semibold text-gray-900">{classes[selectedClass].students.length}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3 mt-3">
                    <div className="bg-blue-50 rounded-lg p-3">
                      <p className="text-xs text-gray-600 mb-1">Present</p>
                      <p className="text-xl font-semibold text-blue-600">{classes[selectedClass].presentCount}</p>
                    </div>
                    <div className="bg-red-50 rounded-lg p-3">
                      <p className="text-xs text-gray-600 mb-1">Absent</p>
                      <p className="text-xl font-semibold text-red-600">{classes[selectedClass].absentCount}</p>
                    </div>
                  </div>
                </div>

                {/* Student List */}
                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-3 flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    Students (Last Session)
                  </h4>
                  <div className="space-y-3">
                    {classes[selectedClass].students.map((student) => (
                      <div key={student.id} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {student.avatar ? (
                            <img src={student.avatar} alt={student.name} className="w-8 h-8 rounded-full" />
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                              <span className="text-xs font-semibold text-green-600">
                                {student.name.charAt(0)}
                              </span>
                            </div>
                          )}
                          <div>
                            <p className="text-sm font-medium text-gray-900">{student.name}</p>
                            <p className="text-xs text-gray-500">{student.id}</p>
                          </div>
                        </div>
                        <Badge variant={student.status === 'Present' ? 'present' : 'absent'} size="sm">
                          {student.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfessorDashboard;
