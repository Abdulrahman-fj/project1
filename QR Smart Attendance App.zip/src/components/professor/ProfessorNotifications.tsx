import { useState } from 'react';
import Sidebar from '../Sidebar';
import TopBar from '../TopBar';
import { Search, FileText, AlertTriangle, Bell, MessageSquare, MoreVertical } from 'lucide-react';

interface ProfessorNotificationsProps {
  onLogout: () => void;
}

const ProfessorNotifications = ({ onLogout }: ProfessorNotificationsProps) => {
  const [activeTab, setActiveTab] = useState<'all' | 'reports' | 'attendance' | 'system' | 'requests'>('all');

  const notifications = [
    {
      id: 1,
      type: 'reports',
      icon: FileText,
      iconColor: 'text-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200',
      title: 'New Report Pending',
      description: 'Monthly attendance report for CS201 is ready for review.',
      time: '10 min ago',
      unread: true,
    },
    {
      id: 2,
      type: 'attendance',
      icon: AlertTriangle,
      iconColor: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
      borderColor: 'border-yellow-200',
      title: 'Low Attendance Warning',
      description: 'CS201 has fallen below 85% attendance threshold this week.',
      time: '1 hour ago',
      unread: true,
    },
    {
      id: 3,
      type: 'requests',
      icon: MessageSquare,
      iconColor: 'text-green-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
      title: 'Absence Request Submitted',
      description: 'John Doe has submitted a medical excuse for Nov 25-27.',
      time: '2 hours ago',
      unread: false,
    },
    {
      id: 4,
      type: 'system',
      icon: Bell,
      iconColor: 'text-gray-600',
      bgColor: 'bg-gray-50',
      borderColor: 'border-gray-200',
      title: 'System Update',
      description: 'The attendance system will undergo maintenance on Dec 1.',
      time: 'Yesterday',
      unread: false,
    },
  ];

  const filteredNotifications = notifications.filter((notif) => {
    if (activeTab === 'all') return true;
    return notif.type === activeTab;
  });

  const tabs = [
    { id: 'all', label: 'All' },
    { id: 'reports', label: 'Reports' },
    { id: 'attendance', label: 'Attendance' },
    { id: 'system', label: 'System' },
    { id: 'requests', label: 'Requests' },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="professor" onLogout={onLogout} userName="Prof. John Smith" />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar showSearch={false} />
        
        <div className="flex-1 overflow-y-auto p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">Notification Center</h1>
            <p className="text-gray-500">Stay updated with class activities and system alerts</p>
          </div>

          {/* Controls */}
          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="relative flex-1 max-w-md w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search notifications..."
                  className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div className="flex gap-2">
                <button className="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm transition-colors">
                  Mark All as Read
                </button>
              </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-2 mt-6 border-b border-gray-200 overflow-x-auto">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-4 py-2 text-sm font-medium transition-colors relative whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'text-green-600'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {tab.label}
                  {activeTab === tab.id && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-green-500" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Notifications List */}
          <div className="space-y-4">
            {filteredNotifications.map((notification) => {
              const Icon = notification.icon;
              return (
                <div
                  key={notification.id}
                  className={`bg-white rounded-xl border-2 ${notification.borderColor} p-6 hover:shadow-md transition-shadow ${
                    notification.unread ? 'border-l-4' : ''
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-10 h-10 ${notification.bgColor} rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <Icon className={`w-5 h-5 ${notification.iconColor}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-4 mb-2">
                        <h3 className="font-semibold text-gray-900">{notification.title}</h3>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-500">{notification.time}</span>
                          <button className="p-1 hover:bg-gray-100 rounded">
                            <MoreVertical className="w-4 h-4 text-gray-400" />
                          </button>
                        </div>
                      </div>
                      <p className="text-sm text-gray-600">{notification.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfessorNotifications;
