import { Search, Moon, Bell } from 'lucide-react';

interface TopBarProps {
  title?: string;
  subtitle?: string;
  searchPlaceholder?: string;
  showSearch?: boolean;
  userAvatar?: string;
  userName?: string;
}

const TopBar = ({ 
  title, 
  subtitle, 
  searchPlaceholder = 'Search users or courses...', 
  showSearch = true,
  userAvatar,
  userName
}: TopBarProps) => {
  return (
    <div className="bg-white border-b border-gray-200 px-8 py-4">
      <div className="flex items-center justify-between">
        <div className="flex-1">
          {showSearch && (
            <div className="max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder={searchPlaceholder}
                  className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
            </div>
          )}
          {(title || subtitle) && (
            <div>
              {title && <h1 className="text-2xl font-semibold text-gray-900">{title}</h1>}
              {subtitle && <p className="text-sm text-gray-500 mt-1">{subtitle}</p>}
            </div>
          )}
        </div>
        
        <div className="flex items-center gap-3">
          <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <Moon className="w-5 h-5 text-gray-600" />
          </button>
          <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors relative">
            <Bell className="w-5 h-5 text-gray-600" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
          {userAvatar && userName && (
            <div className="flex items-center gap-2 ml-2">
              <img src={userAvatar} alt={userName} className="w-9 h-9 rounded-full" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TopBar;
